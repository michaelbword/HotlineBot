import json
import urllib3
import csv
import os
import boto3
import botocore.exceptions
from datetime import datetime, timedelta

# webex_token = 'NDQ4Y2RjZDgtMzEzMC00MTg1LWE5ZjktYWMzZTNiNGU5ODVlNmJkNjEwY2YtN2Mx_PF84_96ed1123-424e-4457-801a-25e3b12a7c6a'  # Hotline Bot
# room_id = 'Y2lzY29zcGFyazovL3VzL1JPT00vNTk2YTc4OTAtOTlhYi0xMWVjLTkxOTUtY2QzY2M2ZGFhMWQ3'  # Hotline

webex_token = os.environ['NDQ4Y2RjZDgtMzEzMC00MTg1LWE5ZjktYWMzZTNiNGU5ODVlNmJkNjEwY2YtN2Mx_PF84_96ed1123-424e-4457-801a-25e3b12a7c6a']
room_id = os.environ['Y2lzY29zcGFyazovL3VzL1JPT00vNTk2YTc4OTAtOTlhYi0xMWVjLTkxOTUtY2QzY2M2ZGFhMWQ3']
bucket_name = os.environ['mapcohotlinebotdev']
object_key = os.environ['https://mapcohotlinebotdev.s3.us-east-2.amazonaws.com/test.csv']
URL = 'https://webexapis.com/v1/'
url_route = "messages"
headers = {
    "Authorization": "Bearer " + webex_token,
    "Content-Type": "application/json"
}
http = urllib3.PoolManager()
s3_client = boto3.client('s3')


def webex_send_message(text):
    message = {
        "roomId": room_id,
        "markdown": text
    }
    try:
        result = http.request('POST',
                              url=URL + url_route,
                              headers=headers,
                              body=json.dumps(message))
        print(result)
        resp = json.loads(result.data.decode('utf-8'))
    except urllib3.exceptions.HTTPError as e:
        print(e)
    else:
        return resp


def get_csv():
    local_file = '/tmp/' + object_key
    try:
        s3_client.bucket(bucket_name).download_file(object_key, local_file)
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            pass
        else:
            raise e
    return local_file


def lambda_handler(event, context):
    ts = datetime.today()
    hour = int(ts.strftime("%H"))  # Get current hour
    if hour <= 5:  # If it's before 05:00, reference previous day
        dt = ts-timedelta(days=1)
    else:
        dt = ts
    day_of_week = dt.strftime("%A")
    csv_file = get_csv()
    file = open(csv_file)
    csvreader = csv.reader(file)
    header = next(csvreader)
    rows = []
    for row in csvreader:
        if row[1].strip() == day_of_week:
            rows.append(row)
    file.close()
    start_time = datetime.strptime(f'{dt.strftime("%m/%d/%Y")} {rows[0][2]}', '%m/%d/%Y %H:%M')
    end_time = start_time+timedelta(hours=int(rows[0][3]))
    txt = f'''
    Hotline for {day_of_week}\n
    Start: {start_time.strftime("%m/%d/%Y %H:%M")}
    End: {end_time.strftime("%m/%d/%Y %H:%M")}
    Tech: {rows[0][0]}
    Phone: {rows[0][4]}
    '''
    print(txt)
    print(webex_send_message(txt))
