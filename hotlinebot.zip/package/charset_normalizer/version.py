"""
Expose version
"""

__version__ = "2.0.12"
VERSION = __version__.split(".")
